import tkinter as tk
from tkinter import ttk

class DersProgramiArayuzu:
    def __init__(self, root):
        self.root = root
        self.root.title("Ders Programı")

        self.dersler = []

        # Ders Saati
        self.label_saati = ttk.Label(root, text="Ders Saati:")
        self.label_saati.grid(row=0, column=0, padx=10, pady=10)
        self.entry_saati = ttk.Entry(root)
        self.entry_saati.grid(row=0, column=1, padx=10, pady=10)

        # Ders Adı
        self.label_ders_adi = ttk.Label(root, text="Ders Adı:")
        self.label_ders_adi.grid(row=1, column=0, padx=10, pady=10)
        self.entry_ders_adi = ttk.Entry(root)
        self.entry_ders_adi.grid(row=1, column=1, padx=10, pady=10)

        # Öğretmen Adı
        self.label_ogretmen_adi = ttk.Label(root, text="Öğretmen Adı:")
        self.label_ogretmen_adi.grid(row=2, column=0, padx=10, pady=10)
        self.entry_ogretmen_adi = ttk.Entry(root)
        self.entry_ogretmen_adi.grid(row=2, column=1, padx=10, pady=10)

        # Haftanın Günleri
        self.label_gunler = ttk.Label(root, text="Haftanın Günleri:")
        self.label_gunler.grid(row=3, column=0, padx=10, pady=10)
        self.entry_gunler = ttk.Entry(root)
        self.entry_gunler.grid(row=3, column=1, padx=10, pady=10)

        # Ders Ekle Butonu
        self.button_ekle = ttk.Button(root, text="Ders Ekle", command=self.ders_ekle)
        self.button_ekle.grid(row=4, column=0, columnspan=2, pady=10)

        # Ders Listesi
        self.liste = ttk.Treeview(root, columns=("Ders Saati", "Ders Adı", "Öğretmen Adı", "Haftanın Günleri"), show="headings")
        self.liste.heading("Ders Saati", text="Ders Saati")
        self.liste.heading("Ders Adı", text="Ders Adı")
        self.liste.heading("Öğretmen Adı", text="Öğretmen Adı")
        self.liste.heading("Haftanın Günleri", text="Haftanın Günleri")
        self.liste.grid(row=5, column=0, columnspan=2, pady=10)

    def ders_ekle(self):
        saati = self.entry_saati.get()
        ders_adi = self.entry_ders_adi.get()
        ogretmen_adi = self.entry_ogretmen_adi.get()
        gunler = self.entry_gunler.get()

        if saati and ders_adi and ogretmen_adi and gunler:
            self.dersler.append((saati, ders_adi, ogretmen_adi, gunler))
            self.listeyi_guncelle()
            self.temizle()

    def listeyi_guncelle(self):
        self.liste.delete(*self.liste.get_children())
        for ders in self.dersler:
            self.liste.insert("", "end", values=ders)

    def temizle(self):
        self.entry_saati.delete(0, tk.END)
        self.entry_ders_adi.delete(0, tk.END)
        self.entry_ogretmen_adi.delete(0, tk.END)
        self.entry_gunler.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = DersProgramiArayuzu(root)
    root.mainloop()
