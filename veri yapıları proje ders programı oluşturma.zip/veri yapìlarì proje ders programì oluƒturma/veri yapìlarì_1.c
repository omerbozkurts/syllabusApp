#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_DERS_SAYISI 10
#define MAX_DERS_ADI_UZUNLUK 50

struct Ders {
    char saati[10];
    char adi[MAX_DERS_ADI_UZUNLUK];
    char ogretmen_adi[50];
    char gunler[20];
};

struct StackNode {
    struct Ders data;
    struct StackNode* next;
};

struct Stack {
    struct StackNode* top;
};

void stack_init(struct Stack* stack) {
    stack->top = NULL;
}

int stack_empty(struct Stack* stack) {
    return stack->top == NULL;
}

void push(struct Stack* stack, struct Ders yeni_ders) {
    struct StackNode* yeni_node = (struct StackNode*)malloc(sizeof(struct StackNode));
    if (!yeni_node) {
        fprintf(stderr, "Hata: Bellek ayrilamadi\n");
        exit(EXIT_FAILURE);
    }

    yeni_node->data = yeni_ders;
    yeni_node->next = stack->top;
    stack->top = yeni_node;

    printf("Yeni ders eklendi.\n");
}

struct Ders pop(struct Stack* stack) {
    if (stack_empty(stack)) {
        fprintf(stderr, "Hata: Yigin bos, ders cikartilamaz.\n");
        exit(EXIT_FAILURE);
    }

    struct StackNode* temp = stack->top;
    struct Ders cikarilan_ders = temp->data;
    stack->top = temp->next;
    free(temp);

    return cikarilan_ders;
}

void listele(struct Stack* stack) {
    struct StackNode* current = stack->top;

    printf("\nDers Programi:\n");
    printf("--------------------------------\n");

    while (current != NULL) {
        printf("Ders Saati: %s\n", current->data.saati);
        printf("Ders Adi: %s\n", current->data.adi);
        printf("Ogretmen Adi: %s\n", current->data.ogretmen_adi);
        printf("Gunler: %s\n", current->data.gunler);
        printf("--------------------------------\n");

        current = current->next;
    }
}

int main() {
    struct Stack ders_stack;
    stack_init(&ders_stack);

    int secim;
    struct Ders yeni_ders;

    do {
        printf("\nDers Programi Uygulamasi\n");
        printf("1. Yeni Ders Ekle\n");
        printf("2. Ders Cikart\n");
        printf("3. Ders Programini Listele\n");
        printf("0. Cikis\n");
        printf("Seciminiz: ");
        scanf("%d", &secim);

        switch (secim) {
            case 1:
                printf("Ders Saati: ");
                scanf("%s", yeni_ders.saati);
                printf("Ders Adi: ");
                scanf("%s", yeni_ders.adi);
                printf("Ogretmen Adi: ");
                scanf("%s", yeni_ders.ogretmen_adi);
                printf("Gunler: ");
                scanf("%s", yeni_ders.gunler);

                push(&ders_stack, yeni_ders);
                break;
            case 2:
                pop(&ders_stack);
                break;
            case 3:
                listele(&ders_stack);
                break;
            case 0:
                printf("Programdan cikiliyor...\n");
                break;
            default:
                printf("Gecersiz secim. Tekrar deneyin.\n");
                break;
        }

    } while (secim != 0);

    return 0;
}

